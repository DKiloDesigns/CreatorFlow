# Cash Persona Workspace

This directory contains all scripts, logs, and artifacts for the Cash persona (crypto/finance hustler).
 
- See [../CASH.md](../CASH.md) for persona definition and protocol.
- Store all trading scripts, automation tools, and money moves logs here.
- Use this as the working directory for all Cash-related development and research. 